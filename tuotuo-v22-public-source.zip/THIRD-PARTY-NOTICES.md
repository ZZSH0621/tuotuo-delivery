# Third party runtime notices

This inventory describes retained runtime components. It is not a license for the whole project, model weights, user-provided art, audio or knowledge content. See `ASSET-RIGHTS-PENDING.md` and `PUBLIC-CANDIDATE.md` for the limited scope of the user’s project-publication authorization and remaining model exclusions.

| Component | Recorded version | License and retained text | Official reference |
| --- | --- | --- | --- |
| Hugging Face Transformers.js browser bundle | 3.8.1 | Apache-2.0; `public/local-asr/vendor/TRANSFORMERS-LICENSE` | https://github.com/huggingface/transformers.js/blob/3.8.1/LICENSE |
| ONNX Runtime Web JS/WASM | 1.22.0-dev.20250409-89f8206ba4 | MIT; `public/local-asr/vendor/ONNXRUNTIME-LICENSE`; additional `ONNXRUNTIME-ThirdPartyNotices.txt` beside it | https://github.com/microsoft/onnxruntime/blob/89f8206ba4/LICENSE |
| Hugging Face Jinja included in browser bundle | 0.5.11 | MIT; `public/local-asr/vendor/JINJA-LICENSE` | https://github.com/huggingface/minijinja.js |
| Sites Vite integration | retained v18 source | MIT; `scripts/vite/sites-vite-plugin.LICENSE` | Copyright 2026 OpenAI, as recorded in bundled license |
| shadcn vendored Tailwind CSS | 4.13.0 filename | MIT; `vendor/shadcn-tailwind-4.13.0.LICENSE.md` | Copyright 2023 shadcn, as recorded in bundled license |

ONNX Runtime third-party notices were fetched from the exact recorded source commit:
https://raw.githubusercontent.com/microsoft/onnxruntime/89f8206ba4/ThirdPartyNotices.txt

Jinja license text was copied from the recorded 0.5.11 installed package associated with the original runtime build. The original retained runtime files are unchanged. The npm application dependencies are not vendored; `package-lock.json` records packages for installation and their own applicable licenses still govern them. This inventory does not assert a complete legal audit of every bundled/transitive component.

Models and FLEURS audio fixture are intentionally excluded. See `public/local-asr/LICENSES.txt` for source references and the outstanding model-license/provenance review. Code/runtime licenses do not establish separate authorization for converted model weights.
