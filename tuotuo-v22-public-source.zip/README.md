# 妥妥 TUOTUO v22 public source

See [PUBLIC-CANDIDATE.md](PUBLIC-CANDIDATE.md) for release status, setup, verification and exclusions.

Production feature baseline: v22. This sanitized source package defaults to API disabled and requires its own hosting/authentication/database/origin/budget setup. No original deployment configuration or provider secrets are included.

Node.js >=22.13.0 is required. Run `npm run install:ci`, then `npm run dev`. For a local production build run `npm run build`, then `npm start`. Open the local URL printed by the command. The root entry is public; paid transcription remains authenticated and opt-in.

The visible voice workflow is Bailian BYOK, with local capture/VAD/WAV and explicit audio/key/charge consent. Old OpenAI server compatibility and local-ASR support code are retained for development, not exposed as extra voice panels. Model weights and FLEURS fixtures are excluded. This is not an offline ASR distribution.

Tests: `node --test tests/*.test.mjs`; types: `npx tsc --noEmit`. Dependencies/build/runtime state are not included. See THIRD-PARTY-NOTICES.md and ASSET-RIGHTS-PENDING.md; public visibility does not grant an overall open-source license.
