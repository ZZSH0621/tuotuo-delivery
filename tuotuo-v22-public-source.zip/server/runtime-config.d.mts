export const SITE_ID:string;
export function runtimeConfig(env:any):{enabled:boolean;origin:string;siteId:string;budgetMicros:number;maxCostMicrosPerRequest:number};
