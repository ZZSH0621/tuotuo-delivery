# TUOTUO visual assets

The four-state image was AI-generated using the user's supplied TUOTUO character reference for the requested redesign. The sleepy-yawn image is retained from the same project. Private source-file identifiers have been removed.

The user has authorized publishing this project, including these retained visuals. This attribution does not grant additional third-party rights or declare the reference character freely licensed. Visual identity only; no medical knowledge or recognition-accuracy claims are implied.
