# Reviewed Bailian BYOK replacement

Baseline: production v21 `0539ced58ad138c19e118bf6ee2059727664e068`; preserves public root fix. Includes previously implemented 390px same-document portrait toggle from `aa61b5dc3a4f4944ac30105b121794a04bc4eb7c`.

## Included
- One visible Bailian voice entry replaces old local/browser/OpenAI UI panels and script bindings. Memo voice uses the same new screen with explicit memo destination. Adopting text appends only a draft; it never creates tasks, changes deadlines or saves memos automatically.
- Bailian Beijing/Singapore default, optional strict workspace subdomain; OpenAI legacy server compatibility retained but not shown in new UI. Fixed official endpoint allowlist, no custom URL or region fallback. Qwen model contract verified against https://help.aliyun.com/zh/model-studio/qwen-audio-asr-http-api .
- Local AudioWorklet capture, bounded WAV conversion and energy-based endpointing. Recording, silence, maximum duration and imports do not upload. User previews, checks one-round audio/key transfer + personal charge consent, then explicitly sends. Model/provider/workspace/key/audio changes revoke consent. Unsaved settings cannot send; region/workspace changes clear key. No automatic retry.
- Key stays page memory only, is sent through same-origin authenticated backend to the selected official provider, and clears on send/background/close. No uploaded `.env.local`, local-server, shared-key resolver or installer modifications were copied or executed.
- Closing/background/alarm interrupts recorder/request, drops stale results and preserves original reminder lifecycle. Cancellation cannot guarantee upstream was not billed.

## Public package verification and deployment
See PUBLIC-CANDIDATE.md for the final public-candidate verification record. The upstream feature baseline is production v22; this package does not carry production runtime settings.

The API is off by default. Before enabling a new deployment, configure a new hosting project, unique SITE_ID in server/runtime-config.mjs, platform authentication, exact HTTPS API_EXPECTED_ORIGIN, D1 bindings and the included quota-table migrations. Select positive integer API_USER_DAILY_BUDGET_MICROS and API_MAX_COST_MICROS_PER_REQUEST with maximum <= budget, then explicitly opt in through API_TRANSCRIPTION_ENABLED. The reserved budget units are not a verified provider-account monetary hard cap. Never set a shared provider secret.

Local/browser/older OpenAI modules remain as source-level development references only; old panels are not visible. Model weights and FLEURS fixtures are excluded and must not be assumed available. No standalone rollback snapshot is bundled.

Only synthetic audio and mocked provider calls were used in automated verification. No real paid transcription, credential validity, quota balance, physical microphone or phone acceptance is claimed. Cancellation cannot guarantee an upstream charge did not occur.
