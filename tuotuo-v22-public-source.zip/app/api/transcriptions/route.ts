import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {runtimeConfig} from '../../../server/runtime-config.mjs';
import {createD1Quota} from '../../../server/quota.mjs';
import {inspectAudio} from '../../../server/audio-validator.mjs';
import {createTranscriptionHandler} from '../../../server/transcription-handler.mjs';
export const dynamic='force-dynamic';
export async function POST(request:Request){const config=runtimeConfig(env);if(!config.enabled)return Response.json({code:'BACKEND_NOT_CONNECTED'},{status:503,headers:{'Cache-Control':'no-store'}});const handler=createTranscriptionHandler({...config,authenticate:async()=>{const user=await getChatGPTUser();return user?{verified:true,id:user.userId}:null;},quota:createD1Quota({db:env.DB,budgetMicros:config.budgetMicros}),inspectAudio,transport:fetch});return handler(request);}
