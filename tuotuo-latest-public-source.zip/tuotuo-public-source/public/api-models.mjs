// Explicit ASR-only allowlist; never accept a provider URL or chat model.
export const API_PROVIDER_ENDPOINT = 'https://api.openai.com/v1/audio/transcriptions';
export const DEFAULT_ASR_MODEL = 'gpt-transcribe';
export const ASR_MODELS = Object.freeze(['gpt-transcribe', 'gpt-4o-transcribe', 'gpt-4o-mini-transcribe', 'gpt-4o-mini-transcribe-2025-12-15', 'whisper-1']);
export const isSupportedASRModel = value => typeof value === 'string' && ASR_MODELS.includes(value);
