# BYOK ASR 源码交付（更新至 v20，2026-10-31）

## 范围与状态

- 基于当前 v18 重设计工作副本，仅修改 API 语音面板、请求契约与模拟测试；视觉、提醒/屏保、任务和本地识别入口保持。
- v20 已保存，提交 `aa61b5dc3a4f4944ac30105b121794a04bc4eb7c`，尚未部署；当前生产仍为 v18。API 默认仍关闭。公开清理版去除内部部署标识、模型及示例音频，不包含真实环境配置。
- 每位用户手动输入自己的 OpenAI API 密钥与 ASR 模型名。无服务器共享 key 或拥有者兜底。
- 仅支持 OpenAI 官方 `https://api.openai.com/v1/audio/transcriptions`，不提供可自定义 URL、代理或其他服务商。
- 允许模型：`gpt-transcribe`（默认）、`gpt-4o-transcribe`、`gpt-4o-mini-transcribe`、`gpt-4o-mini-transcribe-2025-12-15`、`whisper-1`。前后端采用同一明确列表；拒绝聊天模型、实时流与说话人分离模型。账户可用性未经付费实测。
- 仅发送 PCM16 WAV（1–2 声道、8–48 kHz、≤30 秒、≤1900 KiB）；即使上游接受更多格式，本站仍使用更窄限制。

## 密钥、同意和费用边界

- 页面明确展示服务商地址和模型；每次发送需要勾选音频、密钥发送与付费同意。改变音频、模型或密钥会撤销先前同意。
- 密钥只在输入框/请求内存中短暂存在，发送后清空输入框，请求完成/失败清除 FormData 中的 key；关闭、切页、后台、pagehide 会取消并清除。没有 localStorage、sessionStorage、日志或 D1 存储 key。
- 不能保证扩展/密码管理器行为，也不能保证取消请求就不会计费。
- 实际 OpenAI 账单与余额由用户自己的 API 账户决定。本站 D1 额度是每个真实登录身份独立的保守预留，不是 OpenAI 账户硬限额，也不查询账户余额。
- 站内限流默认每用户每分钟 3 次；预留按天、按用户累计；失败不释放预留，不自动重试；换模型不绕过同一用户额度。预算和单次上限必须由运营者按所有允许模型、最长音频及最新计费确认，不能把未核实数字当真实费用保证。

## 待部署条件（本次未执行）

1. 托管入口提供可信 `oai-authenticated-user-id` 与 `oai-authenticated-user-email`。裸部署不得相信用户自行构造的身份头；须保留平台认证边界。
2. D1 绑定名 `DB`；已应用 `drizzle/0000_robust_richard_fisk.sql`（或等效 schema），包含 `api_attempt_windows`、`api_cost_reservations`。不要重复执行两套迁移。
3. Runtime 配置：
   - `API_TRANSCRIPTION_ENABLED=true`：仅经授权后开启；当前样例为 `false`。
   - `API_EXPECTED_ORIGIN`：生产精确 HTTPS origin，无末尾斜杠。
   - `API_USER_DAILY_BUDGET_MICROS`：正整数。
   - `API_MAX_COST_MICROS_PER_REQUEST`：正整数且不大于每日预算；应足以覆盖全部允许模型的最长请求。
   - `SITE_OWNER_USER_ID`：可选，仅用于 owner 状态展示，不是转写准入条件。
   - 不设置 `OPENAI_API_KEY`；每次请求必须自带用户 key。
4. 登录后 GET `/api/session` 做无 OpenAI 调用检查：`authenticated=true, connected=true` 仅证明身份、配置与表可读，不证明提供商模型/余额/网络可用。
5. 之后再由用户明确批准，使用其自己的密钥和虚构音频做一次可能计费的端到端测试。本次未做。

## 验证证据

- `node --test tests/*.test.mjs`：86/86 通过（最新公开候选重跑，复用已安装依赖）；含身份/配额隔离、重复请求、固定上游、无重试、模型白名单、密钥清理、同意撤销、录音中断、提醒与原资源保留。
- `npx tsc --noEmit`：通过。
- `npm run build`：通过，产出 `/api/session` 与 `/api/transcriptions` 路由。
- `git diff --check`：通过。
- 所有上游测试均注入模拟 transport/fetcher；无真实 API 请求、密钥、患者音频或费用。
- 未验：此变更的真实浏览器视觉/输入流程、手机/iOS、生产配置、生产 D1、真实认证链及真实 OpenAI 调用。Node DOM 模拟不等于浏览器验收。
- 许可：本地语音转换权重授权待单独确认，不因本次 API 修改视为可公开再分发；本公开版已补充第三方运行库 notices，并排除模型和示例音频。

## 官方依据

2026-10-31 已读取：
- https://developers.openai.com/api/docs/guides/speech-to-text
- https://developers.openai.com/api/reference/resources/audio/subresources/transcriptions/methods/create

官方当前文档包含 `gpt-transcribe`，因此保留默认值；此处不声称已验证每个用户账户都可调用。
