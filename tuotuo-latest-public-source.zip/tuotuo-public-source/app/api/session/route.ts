import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {runtimeConfig} from '../../../server/runtime-config.mjs';
export const dynamic='force-dynamic';
export async function GET(){const user=await getChatGPTUser();let ready=false;if(user&&runtimeConfig(env).enabled&&env.DB){try{await env.DB.prepare('SELECT site_id FROM api_attempt_windows LIMIT 1').first();await env.DB.prepare('SELECT site_id FROM api_cost_reservations LIMIT 1').first();ready=true;}catch{}}return Response.json({authenticated:!!user,connected:!!user&&ready,owner:!!user&&!!env.SITE_OWNER_USER_ID&&user.userId===env.SITE_OWNER_USER_ID},{headers:{'Cache-Control':'no-store'}});}
